import React from 'react';
import { useTranslation } from 'react-i18next';

const LanguageSwitcher: React.FC = () => {
  const { i18n, t } = useTranslation();

  // 获取当前语言（去掉地区代码，如 en-US -> en）
  const currentLanguage = i18n.language.split('-')[0];

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    localStorage.setItem('language', lng);
  };

  return (
    <div style={{
      position: 'fixed',
      top: '20px',
      right: '20px',
      zIndex: 1000
    }}>
      <select
        value={currentLanguage}
        onChange={(e) => changeLanguage(e.target.value)}
        style={{
          padding: '8px 12px',
          borderRadius: '6px',
          border: '1px solid #ddd',
          backgroundColor: 'white',
          cursor: 'pointer',
          fontSize: '14px'
        }}
      >
        {/* ✅ 正确：只传一个参数 */}
        <option value="en">🇬🇧 {t('language.en')}</option>
        <option value="zh">🇨🇳 {t('language.zh')}</option>
      </select>
    </div>
  );
};

export default LanguageSwitcher;
